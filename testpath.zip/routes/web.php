<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', ['uses' => 'ReferralsController@index', 'as' => 'index']);

Route::get('regForm', ['uses' => 'ReferralsController@regForm', 'as' => 'regForm']);
Route::post('add_user', ['uses' => 'ReferralsController@saveUser', 'as' => 'saveUser']);
Route::get('user_list', ['uses' => 'ReferralsController@userList', 'as' => 'userList']);
Route::get('referral_user_list', ['uses' => 'ReferralsController@referralUserList', 'as' => 'referralUserList']);
