<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Referrals;

class ReferralsController extends Controller
{
    
    public function index(){
        $data = array();      
        return view('index', $data);
    }

    public function regForm(){
        $data = array();      
        return view('index', $data);
    }

    public function saveUser(Request $request){
      
        if ($request->isMethod('post')) {
            $request->validate([
                'name' => 'required|regex:/^[\pL\s\-]+$/u|max:150',
                'email' => 'required|email|unique:tbl_user,email',               
                'mobile' => 'required|numeric|digits:10|unique:tbl_user,mobile', 
                'referral_code' =>  'sometimes|nullable|min:6|max:6',  
                'gender' => 'required',             
                'technology' => 'required',      
            ]);

            if ($request->input('referral_code')) {
                $checkReferralCode = Referrals::where('referral_code',$request->referral_code)->first();
                if(!$checkReferralCode){
                    return redirect()->back()->withError('You have enter incorrect referral code!');
                }else{
                    $insertUser = new Referrals;
                    $insertUser->name           = $request->input('name');
                    $insertUser->email          = $request->input('email');
                    $insertUser->mobile         = $request->input('mobile');
                    $insertUser->gender         = $request->input('gender');
                    $insertUser->technology     = $request->input('technology');
                    $insertUser->referral_code  = $this->rand(6);
                    $insertUser->use_referral   = true;
                    $insertUser->referral_point = 20;
                    $insertUser->use_referral_code = $request->input('referral_code');
                    if($insertUser->save()){ 
                        Referrals::where('id', $checkReferralCode->id)->update(['referral_point' => $checkReferralCode->referral_point+10
                        ]);
                    }
                    return redirect(route('referralUserList'))->withSuccess('User created successfully');
                }

            }else{
                $insertUser = new Referrals;
                $insertUser->name           = $request->input('name');
                $insertUser->email          = $request->input('email');
                $insertUser->mobile         = $request->input('mobile');
                $insertUser->gender         = $request->input('gender');
                $insertUser->technology     = $request->input('technology');
                $insertUser->referral_code  = $this->rand(6);
                $insertUser->save();
                return redirect(route('userList'))->withSuccess('User created successfully');
            }

        } 
    }

    public function userList(){
        $data = array();
        $data['userlist'] = Referrals::Where('use_referral',false)->paginate(10);       
        return view('userlist', $data);
    }

    public function referralUserList(){
        $data = array();
        $data['userlist'] = Referrals::Where('use_referral',true)->paginate(10); 
        return view('referralUserList', $data);
    }

    public function rand($length_of_string){
        $str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; 
        return substr(str_shuffle($str_result), 0, $length_of_string); 
    }
}
