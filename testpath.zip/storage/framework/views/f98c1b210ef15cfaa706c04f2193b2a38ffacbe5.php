
<?php $__env->startSection('content'); ?>

        <h2>Referral User List</h2>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Mobile</th>
              <th scope="col">Gender</th>
              <th scope="col">Technology</th>
              <th scope="col">Use Referral Code</th>
              <th scope="col">Referral Point</th>
            </tr>
          </thead>
          <tbody>
            <?php if(!empty($userlist) && count($userlist)): ?>
            <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>              
              <td><?php echo e($userlist->firstItem() + $key); ?></td>
              <td><?php echo e($data->name); ?></td>
              <td><?php echo e($data->email); ?></td>
              <td><?php echo e($data->mobile); ?></td>
              <td><?php if($data->gender == 1): ?> Male <?php else: ?> Female <?php endif; ?></td>
              <td><?php if($data->technology == 1): ?> PHP <?php elseif($data->technology == 2): ?> Angular <?php else: ?> NodeJs <?php endif; ?></td>
              <td><?php echo e($data->use_referral_code); ?></td>
              <td><?php echo e($data->referral_point); ?></td>             
            </tr> 
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
             <?php else: ?>
             <tr>
               <td colspan="8" style="text-align:center"><i class="fa fa-search"> No Data Avaliable</td>
             </tr> 
             <?php endif; ?>          
          </tbody>
        </table>
        <?php echo $userlist->links('pagination::bootstrap-4'); ?>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testpath\resources\views/referralUserList.blade.php ENDPATH**/ ?>