<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        
    </head>
    <body>
        <div class="container">
        <div class="regform">
        <?php if(Session('success')): ?>                      
        <div class="alert alert-success alert-dismissible alert-solid alert-label-icon fade show" role="alert">
            <i class="fa fa-check label-icon"></i>
            <?php echo e(Session('success')); ?>

            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(Session('error')): ?>                        
            <div class="alert alert-danger alert-dismissible alert-solid alert-label-icon fade show" role="alert">
            <i class="fa fa-exclamation-triangle label-icon"></i>
            <?php echo e(Session('error')); ?>

            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\testpath\resources\views/layout/masterlayout.blade.php ENDPATH**/ ?>