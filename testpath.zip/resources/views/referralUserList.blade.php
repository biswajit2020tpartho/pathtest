@extends('layout.masterlayout')
@section('content')

        <h2>Referral User List</h2>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Mobile</th>
              <th scope="col">Gender</th>
              <th scope="col">Technology</th>
              <th scope="col">Use Referral Code</th>
              <th scope="col">Referral Point</th>
            </tr>
          </thead>
          <tbody>
            @if(!empty($userlist) && count($userlist))
            @foreach($userlist as $key=>$data)
            <tr>              
              <td>{{ $userlist->firstItem() + $key  }}</td>
              <td>{{ $data->name }}</td>
              <td>{{ $data->email }}</td>
              <td>{{ $data->mobile }}</td>
              <td>@if($data->gender == 1) Male @else Female @endif</td>
              <td>@if($data->technology == 1) PHP @elseif($data->technology == 2) Angular @else NodeJs @endif</td>
              <td>{{ $data->use_referral_code }}</td>
              <td>{{ $data->referral_point }}</td>             
            </tr> 
             @endforeach  
             @else
             <tr>
               <td colspan="8" style="text-align:center"><i class="fa fa-search"> No Data Avaliable</td>
             </tr> 
             @endif          
          </tbody>
        </table>
        {!! $userlist->links('pagination::bootstrap-4') !!}
   @endsection