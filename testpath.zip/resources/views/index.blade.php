@extends('layout.masterlayout')
@section('content')


        <p><a href="{{ route('userList') }}">User List</a></p>
        <p><a href="{{ route('referralUserList') }}">Referral User List</a></p>
        <div class="container mt-3">
          <h2>Registration form</h2>
          <form action="{{ route('saveUser') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="mb-3 mt-3">
              <label for="email">Name:<span class="text-danger" title="This field is required">*</span></label>
              <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" value="{{ old('name') }}">
              @error('name')
                <div class="text-danger mt-1" role="alert">
                    <strong>{{ $message }}</strong>
                </div>
              @enderror
            </div>
            <div class="mb-3 mt-3">
              <label for="email">Email:<span class="text-danger" title="This field is required">*</span></label>
              <input type="text" class="form-control" id="email" placeholder="Enter email" name="email" value="{{ old('email') }}">
              @error('email')
                <div class="text-danger mt-1" role="alert">
                    <strong>{{ $message }}</strong>
                </div>
              @enderror
            </div>
            <div class="mb-3 mt-3">
              <label for="email">Mobile:<span class="text-danger" title="This field is required">*</span></label>
              <input type="text" class="form-control" id="mobile" placeholder="Enter mobile" name="mobile" value="{{ old('mobile') }}">
              @error('mobile')
                <div class="text-danger mt-1" role="alert">
                    <strong>{{ $message }}</strong>
                </div>
              @enderror
            </div>
            <div class="mb-3">
              <label for="pwd">Referral Code :</label>
              <input type="text" class="form-control" id="referral_code" placeholder="Enter Referral Code" name="referral_code" value="{{ old('referral_code') }}">
              @error('referral_code')
                <div class="text-danger mt-1" role="alert">
                    <strong>{{ $message }}</strong>
                </div>
              @enderror
            </div>

            <div class="form-check mb-3">
                <label for="pwd">Gener :</label>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1" value="1" @if(old('gender')==1) checked @endif>
                  <label class="form-check-label" for="flexRadioDefault1">
                    Male
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="2" @if(old('gender')==2) checked @endif>
                  <label class="form-check-label" for="flexRadioDefault2">
                    Female
                  </label>
                </div>
                @error('gender')
                <div class="text-danger mt-1" role="alert">
                    <strong>{{ $message }}</strong>
                </div>
                @enderror
            </div>

            <div class="form-check mb-3">
                <label for="pwd">Technology :</label>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="1" id="flexCheckDefault" name="technology" @if(old('technology')==1) checked @endif>
                  <label class="form-check-label" for="flexCheckDefault">
                    PHP
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="2" id="flexCheckChecked" name="technology" @if(old('technology')==2) checked @endif>
                  <label class="form-check-label" for="flexCheckChecked">
                    Angular
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="3" id="flexCheckChecked1" name="technology" @if(old('technology')==3) checked @endif>
                  <label class="form-check-label" for="flexCheckChecked1">
                    Angular
                  </label>
                </div>
                @error('technology')
                <div class="text-danger mt-1" role="alert">
                    <strong>{{ $message }}</strong>
                </div>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
        @endsection